def handler(event,context):
    print('hi')
 
